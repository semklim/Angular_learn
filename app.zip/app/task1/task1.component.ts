import { Component } from '@angular/core';

@Component({
  selector: 'app-task1',
  templateUrl: './task1.component.html',
  styleUrls: ['./task1.component.css']
})
export class Task1Component {
	dateDay = 0;
	dateHour = 0;
	dateMinute = 0;
	title = 'AngularLesson';

	constructor(){
		setInterval(()=> {
			const date = new Date();
			this.dateDay = date.getDate();
			this.dateHour = date.getHours();
			this.dateMinute = date.getMinutes();
		}, 1000)
	}
}