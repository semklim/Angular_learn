import { Component } from '@angular/core';

@Component({
  selector: 'app-task2',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class Task2Component {
  title = 'AngularLesson';

  dateDay = 0;
  dateHour = 0;
  dateMinute = 0;
  dateSecond = 0;
  constructor(){
	  setInterval(()=> {
		  const date = new Date();
		  this.dateDay = date.getDate();
		  this.dateHour = date.getHours();
		  this.dateMinute = date.getMinutes();
		  this.dateSecond = date.getSeconds();
	  }, 1000)
  }
}
